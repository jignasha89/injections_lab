'use client';

import { 
  HelpCircle, 
  Search, 
  ShieldCheck, 
  Activity, 
  FileText,
  TerminalSquare
} from 'lucide-react';

export default function HelpPage() {
  return (
    <div className="space-y-8 text-text-primary font-sans pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-border-strong pb-6">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-text-primary flex items-center gap-3">
            <HelpCircle className="w-6 h-6 text-brand-primary" />
            Documentation & Help
          </h1>
          <p className="text-sm text-text-secondary mt-1">
            Learn how the Injection Lab scanner works and how to interpret your results.
          </p>
        </div>
      </div>

      <div className="space-y-6">
        
        {/* Section 1: Overview */}
        <section className="cyber-card p-6 md:p-8">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-surface-hover rounded-lg border border-border-strong text-brand-primary">
              <TerminalSquare className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-text-primary mb-2">What is Injection Lab?</h2>
              <p className="text-sm text-text-secondary leading-relaxed mb-4">
                Injection Lab is an educational vulnerability assessment tool designed to help you understand, detect, and remediate various injection flaws. It features a smart, contextual scanning engine that analyzes web applications for 55 different types of vulnerabilities ranging from Cross-Site Scripting (XSS) to Blind SQL Injection.
              </p>
            </div>
          </div>
        </section>

        {/* Section 2: How Scanning Works */}
        <section className="cyber-card p-6 md:p-8">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-surface-hover rounded-lg border border-border-strong text-brand-primary">
              <Search className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-text-primary mb-2">Heuristic & Contextual Targeting</h2>
              <p className="text-sm text-text-secondary leading-relaxed mb-4">
                Unlike traditional scanners that blindly fire every payload at every input field (causing massive noise and long scan times), our engine uses <strong>contextual targeting</strong>.
              </p>
              <ul className="list-disc pl-5 text-sm text-text-secondary space-y-2">
                <li><strong className="text-text-primary">Parameter Analysis:</strong> The scanner analyzes parameter names (e.g., <code className="text-brand-primary">?login=</code>, <code className="text-brand-primary">?search=</code>, <code className="text-brand-primary">?file=</code>) to infer their purpose.</li>
                <li><strong className="text-text-primary">Targeted Payloads:</strong> It will only send SQL Authentication Bypass payloads to credential fields, XSS payloads to search/display fields, and Path Traversal payloads to file/path parameters.</li>
                <li><strong className="text-text-primary">Efficiency:</strong> This approach drastically reduces the total number of HTTP requests and produces highly accurate, relevant results.</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Section 3: Active Verification */}
        <section className="cyber-card p-6 md:p-8">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-surface-hover rounded-lg border border-border-strong text-brand-primary">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-text-primary mb-2">Active vs. Passive Modes</h2>
              <p className="text-sm text-text-secondary leading-relaxed mb-4">
                When you run a scan, the engine performs a two-stage analysis to ensure high confidence:
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
                <div className="inner-cell p-4">
                  <h3 className="text-sm font-semibold text-text-primary flex items-center gap-2 mb-2">
                    <Activity className="w-4 h-4 text-text-secondary" /> Passive Phase
                  </h3>
                  <p className="text-[13px] text-text-secondary leading-relaxed">
                    The scanner maps the target application by discovering pages and parameters. It builds a structural profile without sending any malicious payloads.
                  </p>
                </div>
                <div className="inner-cell p-4">
                  <h3 className="text-sm font-semibold text-text-primary flex items-center gap-2 mb-2">
                    <ShieldCheck className="w-4 h-4 text-brand-primary" /> Active Phase (Canaries)
                  </h3>
                  <p className="text-[13px] text-text-secondary leading-relaxed">
                    The engine sends safe "canary" payloads (like <code className="text-brand-primary font-mono text-[11px]">' AND 1=2--</code> or <code className="text-brand-primary font-mono text-[11px]">../../../etc/passwd</code>) and verifies structural changes, time delays, and HTTP headers to confidently confirm a vulnerability.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Section 4: Step-by-Step Guide */}
        <section className="cyber-card p-6 md:p-8">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-surface-hover rounded-lg border border-border-strong text-brand-primary">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-text-primary mb-2">Step-by-Step Guide</h2>
              
              <h3 className="text-md font-semibold text-text-primary mt-4 mb-2">How to Run a Scan</h3>
              <ol className="list-decimal pl-5 text-sm text-text-secondary space-y-2 mb-6">
                <li>Navigate to the <strong className="text-text-primary">Scanner</strong> page using the sidebar navigation.</li>
                <li>Enter the Target URL of the application you want to test (ensure you have permission to test this target).</li>
                <li>Adjust your scan settings (e.g., maximum depth, concurrency limits) if needed.</li>
                <li>Click the <strong className="text-text-primary">Start Audit</strong> button. The engine will begin its Passive and Active scanning phases.</li>
                <li>Wait for the progress bar to complete. Do not close the window during the scan.</li>
              </ol>

              <h3 className="text-md font-semibold text-text-primary mb-2">How to Save & Export Reports</h3>
              <ol className="list-decimal pl-5 text-sm text-text-secondary space-y-2">
                <li>Once a scan completes, it is automatically saved to your database and appears in the <strong className="text-text-primary">History</strong> page.</li>
                <li>Navigate to the <strong className="text-text-primary">History</strong> page and click on any past test to view its detailed audit report.</li>
                <li>In the top right corner of the report, you will find <strong className="text-text-primary">Export CSV</strong> and <strong className="text-text-primary">Download PDF report</strong> buttons.</li>
                <li>Click either button to generate and save a professional security report to your local machine.</li>
              </ol>
            </div>
          </div>
        </section>

      </div>
    </div>
  );
}
