'use client';

import { useState, useRef, useEffect } from 'react';
import { api } from '@/lib/api';
import ParseTreeGraphic from '@/components/shared/ParseTreeGraphic';
import {
  Scan,
  ShieldAlert,
  CheckCircle,
  Server,
  Save,
  ChevronDown,
  ChevronUp,
  Globe,
  Code2,
  Shield,
  Eye,
  BookOpen,
  AlertCircle,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

import { useScannerStore, ScanResult, Finding } from '@/store/scannerStore';

const getSeverityBadgeClass = (severity: string) => {
  switch (severity) {
    case 'Critical': return 'severity-critical';
    case 'High': return 'severity-high';
    case 'Medium': return 'severity-medium';
    case 'Low': return 'severity-low';
    case 'Info':
    default: return 'severity-info';
  }
};

const getConfidenceBadgeClass = (confidence: string) => {
  switch (confidence) {
    case 'Confirmed': return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
    case 'Likely': return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
    case 'Possible': return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
    default: return 'bg-surface-base border-border-strong text-text-secondary';
  }
};

export default function ScannerPage() {
  const { url, setUrl, authorized, setAuthorized, loading, result, error, setError, startScan, reset } = useScannerStore();

  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [expandedFinding, setExpandedFinding] = useState<number | null>(null);
  const [filterFamily, setFilterFamily] = useState<string>('All');

  /* Custom inline validation state */
  const [urlTouched, setUrlTouched] = useState(false);
  const [urlError, setUrlError] = useState('');
  const formRef = useRef<HTMLFormElement>(null);

  const validateUrl = (value: string): string => {
    if (!value.trim()) return 'An endpoint URL is required to begin analysis.';
    try {
      new URL(value);
      return '';
    } catch {
      return 'Enter a valid URL starting with http:// or https://';
    }
  };

  const handleUrlChange = (value: string) => {
    setUrl(value);
    if (urlTouched) {
      setUrlError(validateUrl(value));
    }
  };

  const handleUrlBlur = () => {
    setUrlTouched(true);
    setUrlError(validateUrl(url));
  };

  const handleScan = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaveSuccess(false);
    setExpandedFinding(null);
    setFilterFamily('All');

    /* Custom validation — prevent native tooltip */
    const validationError = validateUrl(url);
    if (validationError) {
      setUrlTouched(true);
      setUrlError(validationError);
      return;
    }

    await startScan();
  };

  const handleSaveReport = async () => {
    if (!result) return;
    setSaving(true);
    setSaveSuccess(false);
    try {
      await api.post('/reports/generate', {
        title: `Assessment — ${result.domain}`,
        targetUrl: result.targetUrl,
        scanType: 'url',
        summary: result.summary,
        findings: result.findings,
        techStack: result.techStackClues,
      });
      setSaveSuccess(true);
    } catch (err) {
      console.error(err);
      setError('Failed to save report.');
    } finally {
      setSaving(false);
    }
  };

  const [elapsed, setElapsed] = useState(0);

  // Timer for scan progress
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (loading) {
      setElapsed(0);
      timer = setInterval(() => setElapsed(prev => prev + 1), 1000);
    }
    return () => clearInterval(timer);
  }, [loading]);

  const filteredFindings = result?.findings.filter(
    (f) => filterFamily === 'All' || f.injectionFamily === filterFamily
  ) ?? [];

  const families = result
    ? ['All', ...Object.keys(result.summary.injectionFamilyCounts)]
    : ['All'];

  // ─── STATE 1: CONFIGURATION (EMPTY OR LOADING) ───
  if (!result) {
    return (
      <div className="max-w-4xl mx-auto pt-12 pb-24 space-y-12 text-text-primary font-sans">
        
        {/* Hero Identity */}
        <div className="text-center space-y-4">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-surface-base border border-border-strong mb-2">
            <Scan className="w-8 h-8 text-brand-primary" />
          </div>
          <h1 className="text-3xl font-semibold tracking-tight text-text-primary">
            New Security Assessment
          </h1>
          <p className="text-sm text-text-secondary max-w-xl mx-auto leading-relaxed">
            Configure a target endpoint for deep inspection. Injection Lab will perform a structural analysis across 55+ known vulnerability patterns including SQLi, XSS, and Command Injection.
          </p>
        </div>

        {/* Primary Interaction: Target URL */}
        <div className="cyber-card p-8 md:p-12 shadow-2xl">
          <form ref={formRef} onSubmit={handleScan} noValidate className="space-y-8">
            <div>
              <label htmlFor="target-url" className="block text-xs font-semibold text-text-secondary uppercase tracking-widest mb-4">
                Target URL
              </label>
              <div className="relative group">
                <input
                  id="target-url"
                  type="text"
                  placeholder="https://target.com/page?id=1&user=admin"
                  value={url}
                  onChange={(e) => handleUrlChange(e.target.value)}
                  onBlur={handleUrlBlur}
                  disabled={loading}
                  className={`cyber-input font-mono w-full pl-12 pr-6 py-5 text-lg md:text-xl text-text-primary placeholder:text-text-secondary/30 transition-all ${urlTouched && urlError ? 'border-severity-critical focus:border-severity-critical focus:ring-severity-critical/20' : 'focus:border-border-focus'}`}
                />
                <Globe className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-text-secondary group-focus-within:text-brand-primary transition-colors" />
              </div>
              {urlTouched && urlError && (
                <div className="mt-3 flex items-center gap-2 text-sm font-medium text-severity-critical">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{urlError}</span>
                </div>
              )}
            </div>

            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pt-6 border-t border-border-subtle">
              <div className="flex items-start gap-3 flex-1">
                <input
                  type="checkbox"
                  id="authorized"
                  checked={authorized}
                  onChange={(e) => setAuthorized(e.target.checked)}
                  disabled={loading}
                  className="mt-1 h-5 w-5 rounded border-border-strong bg-transparent text-brand-primary focus:ring-brand-primary/40 accent-[var(--color-brand-primary)] cursor-pointer"
                />
                <label htmlFor="authorized" className="text-sm text-text-secondary cursor-pointer select-none leading-relaxed">
                  I confirm authorization to inspect this target and understand that structural parameter analysis will be performed.
                </label>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="btn-cyber-primary px-10 py-4 text-base font-semibold flex items-center justify-center gap-3 w-full md:w-auto shrink-0 shadow-lg disabled:opacity-50 transition-all"
              >
                <Shield className="w-5 h-5" />
                {loading ? 'Initiating...' : 'Start Assessment'}
              </button>
            </div>
            
            {error && (
              <div className="p-4 bg-severity-critical/10 border border-severity-critical/20 text-severity-critical text-sm font-medium flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                {error}
              </div>
            )}
          </form>
        </div>

        {/* Scan Progress State */}
        {loading && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="cyber-card p-8 border-brand-primary/30">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 mb-8">
              <div className="flex items-center gap-4">
                <div className="relative">
                  <div className="w-10 h-10 rounded-full border-2 border-brand-primary/20 border-t-brand-primary animate-spin" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Scan className="w-4 h-4 text-brand-primary" />
                  </div>
                </div>
                <div>
                  <h3 className="text-base font-semibold text-text-primary">Analysis in progress</h3>
                  <p className="text-xs text-text-secondary font-mono mt-1">Target: {new URL(url).hostname}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-[10px] font-semibold text-text-secondary uppercase tracking-widest mb-1">Elapsed Time</p>
                <p className="text-2xl font-mono text-text-primary">{Math.floor(elapsed / 60).toString().padStart(2, '0')}:{(elapsed % 60).toString().padStart(2, '0')}</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between text-xs font-mono text-text-secondary">
                <span>Phase {Math.min(4, Math.floor(elapsed / 2) + 1)}/4: {
                  elapsed < 2 ? 'Reconnaissance & Mapping' :
                  elapsed < 4 ? 'Structural Parameter Analysis' :
                  elapsed < 6 ? 'Heuristic Pattern Matching' :
                  'Generating Intelligence Report'
                }</span>
                <span className="text-brand-primary">{Math.min(100, Math.floor((elapsed / 6) * 100))}%</span>
              </div>
              <div className="h-2 w-full bg-surface-hover rounded-full overflow-hidden">
                <div 
                  className="h-full bg-brand-primary transition-all duration-1000 ease-linear"
                  style={{ width: `${Math.min(100, (elapsed / 6) * 100)}%` }}
                />
              </div>
            </div>
          </motion.div>
        )}


      </div>
    );
  }

  // ─── STATE 2: RESULTS VIEW ───
  return (
    <div className="space-y-8 text-text-primary font-sans pb-16 max-w-[1600px]">
      
      {/* Condensed Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 section-divider">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-text-primary flex items-center gap-3">
            <Shield className="w-6 h-6 text-brand-primary" />
            Assessment Complete
          </h1>
          <p className="text-sm font-mono text-text-secondary mt-2">
            Target: <span className="text-text-primary">{result.targetUrl}</span>
          </p>
        </div>
        <div className="flex items-center gap-4">
          <button
            onClick={() => {
              reset();
              setUrlTouched(false);
              setUrlError('');
            }}
            className="text-xs font-semibold text-text-secondary hover:text-text-primary transition-colors"
          >
            New Scan
          </button>
          <button
            onClick={handleSaveReport}
            disabled={saving || saveSuccess}
            className="btn-cyber-primary px-5 py-2.5 text-xs font-semibold flex items-center gap-2 disabled:opacity-50 shrink-0"
          >
            <Save className="w-3.5 h-3.5" />
            {saving ? 'Saving…' : saveSuccess ? '✓ Saved' : 'Save Report'}
          </button>
        </div>
      </div>

      {saveSuccess && (
        <div className="p-4 bg-severity-low/10 text-severity-low border border-severity-low/20 text-sm font-medium flex items-center gap-2">
          <CheckCircle className="w-4 h-4 shrink-0" />
          Report successfully saved to Workspace.
        </div>
      )}

      {/* Primary Results Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-6 bg-surface-base border-l-4 border-l-severity-critical">
          <p className="text-[10px] font-semibold text-text-secondary uppercase tracking-widest mb-2">Risk Score</p>
          <p className={`stat-hero text-4xl ${result.summary.riskScore >= 7 ? 'text-severity-critical' : result.summary.riskScore >= 4 ? 'text-severity-medium' : 'text-severity-low'}`}>
            {result.summary.riskScore} <span className="text-lg text-text-secondary font-sans">/ 10</span>
          </p>
        </div>
        <div className="p-6 bg-surface-hover">
          <p className="text-[10px] font-semibold text-text-secondary uppercase tracking-widest mb-2">Findings</p>
          <p className="stat-hero text-4xl text-text-primary">{result.summary.injectionPoints}</p>
        </div>
        <div className="p-6 bg-surface-hover">
          <p className="text-[10px] font-semibold text-text-secondary uppercase tracking-widest mb-2">Parameters Analyzed</p>
          <p className="stat-hero text-4xl text-text-primary">{result.summary.parameters}</p>
        </div>
        <div className="p-6 bg-surface-hover">
          <p className="text-[10px] font-semibold text-text-secondary uppercase tracking-widest mb-2">OWASP Coverage</p>
          <p className="stat-hero text-4xl text-text-primary">{result.summary.owaspCoverage.length}</p>
        </div>
      </div>

      {/* Tech stack */}
      {result.techStackClues.length > 0 && (
        <div className="flex flex-wrap items-center gap-3 pt-4">
          <span className="text-xs text-text-secondary font-medium uppercase tracking-widest flex items-center gap-2">
            <Server className="w-3.5 h-3.5" /> Intelligence:
          </span>
          {result.techStackClues.map((t) => (
            <span key={t} className="px-2 py-1 bg-surface-hover border border-border-subtle text-[11px] font-mono text-text-secondary">{t}</span>
          ))}
        </div>
      )}

              {/* Family filter */}
              <div className="flex gap-2 flex-wrap">
                {families.map((fam) => (
                  <button
                    key={fam}
                    onClick={() => setFilterFamily(fam)}
                    className={`px-3.5 py-2 rounded-md text-xs font-medium border transition-all ${filterFamily === fam
                      ? 'bg-brand-primary/10 text-brand-primary border-brand-primary/20 '
                      : 'bg-transparent text-text-secondary border-border-subtle hover:bg-surface-base hover:text-text-primary'
                    }`}
                  >
                    {fam === 'All' ? `All (${result.findings.length})` : `${fam.split(' / ')[0]} (${result.summary.injectionFamilyCounts[fam] || 0})`}
                  </button>
                ))}
              </div>

              {/* Finding cards */}
              <div className="space-y-3">
                {filteredFindings.map((finding, idx) => {
                  const isExpanded = expandedFinding === idx;
                  return (
                    <div key={idx} className="cyber-card overflow-hidden">
                      <button
                        onClick={() => setExpandedFinding(isExpanded ? null : idx)}
                        className="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-bg-base/50 transition-colors gap-4"
                        aria-expanded={isExpanded}
                      >
                        <div className="space-y-1.5 min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className={`severity-badge ${getSeverityBadgeClass(finding.severity)}`}>
                              {finding.severity}
                            </span>
                            <span className={`text-[10px] font-mono px-2 py-0.5 border rounded ${getConfidenceBadgeClass(finding.confidence)}`}>
                              {finding.confidence}
                            </span>
                            <span className="text-sm font-semibold text-text-primary">{finding.type}</span>
                          </div>
                          <p className="text-[11px] font-mono text-text-secondary truncate">{finding.location}</p>
                        </div>
                        {isExpanded ? <ChevronUp className="w-4 h-4 text-text-secondary shrink-0" /> : <ChevronDown className="w-4 h-4 text-text-secondary shrink-0" />}
                      </button>

                      <AnimatePresence>
                        {isExpanded && (
                          <motion.div 
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="px-5 pb-5 pt-4 border-t border-border-strong space-y-5 text-xs"
                          >
                            {/* Metadata badges */}
                            <div className="flex flex-wrap gap-2">
                              <span className="font-mono text-[10px] px-2.5 py-1 rounded-md inner-cell text-text-secondary">CVSS {finding.cvss}</span>
                              <span className="font-mono text-[10px] px-2.5 py-1 rounded-md inner-cell text-text-secondary">{finding.cwe}</span>
                              <span className="font-mono text-[10px] px-2.5 py-1 rounded-md inner-cell text-text-secondary">{finding.owasp}</span>
                            </div>

                            {/* Parameter */}
                            {finding.parameter && (
                              <div>
                                <span className="text-[10px] font-semibold text-text-secondary uppercase tracking-widest block mb-2">
                                  Query parameter
                                </span>
                                <p className="text-sm font-mono text-brand-primary inner-cell p-3 break-all">
                                  {finding.parameter}{finding.paramValue ? ` = ${finding.paramValue}` : ''}
                                </p>
                              </div>
                            )}

                            {/* Business impact */}
                            <div>
                              <span className="text-[10px] font-semibold text-text-secondary uppercase tracking-widest flex items-center gap-1.5 mb-2">
                                <BookOpen className="w-3 h-3" /> Business impact
                              </span>
                              <p className="text-text-primary leading-relaxed font-sans">
                                {finding.severity === 'Critical' || finding.severity === 'High'
                                  ? 'This flaw could let an attacker compromise sensitive data, take over accounts, or access underlying systems. Immediate remediation is required.'
                                  : 'This issue could help an attacker gather system information or chain with other vulnerabilities. Address it to maintain defense in depth.'}
                              </p>
                            </div>

                            {/* Technical details */}
                            <div>
                              <span className="text-[10px] font-semibold text-text-secondary uppercase tracking-widest flex items-center gap-1.5 mb-2">
                                <Eye className="w-3 h-3" /> Technical details
                              </span>
                              <p className="text-text-primary leading-relaxed font-sans">{finding.description}</p>
                            </div>

                            {/* Evidence */}
                            {finding.evidence && (
                              <div className="inner-cell p-4 font-mono">
                                <span className="text-[10px] font-semibold text-text-secondary uppercase tracking-widest block mb-2">Evidence</span>
                                <p className="text-text-primary text-[11px] leading-relaxed break-words">{finding.evidence}</p>
                              </div>
                            )}

                            {/* PoC payload */}
                            {finding.pocPayload && (
                              <div>
                                <span className="text-[10px] font-semibold text-text-secondary uppercase tracking-widest flex items-center gap-1.5 mb-2">
                                  <Code2 className="w-3 h-3" /> PoC payload
                                </span>
                                <div className="inner-cell p-3 font-mono text-[11px] text-text-primary break-all">
                                  {finding.pocPayload}
                                </div>
                              </div>
                            )}

                            {/* Remediation */}
                            <div className="p-4 rounded-md bg-surface-base border border-border-strong">
                              <span className="text-[10px] font-semibold text-text-secondary uppercase tracking-widest flex items-center gap-1.5 mb-2">
                                <Shield className="w-3 h-3" /> Remediation
                              </span>
                              <p className="text-text-primary leading-relaxed font-sans">{finding.recommendation}</p>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                })}
              </div>
    </div>
  );
}
