'use client';

import { useState, useEffect, useRef } from 'react';
import { Terminal, Radio, Target } from 'lucide-react';
import GlobeVisualization from '@/components/dashboard/GlobeVisualization';
import Link from 'next/link';

const MOCK_LOGS = [
  "Initializing payload evasion engine...",
  "WAF evasion required for target constraints.",
  "Loading NoSQL injection vector (ID: 412).",
  "Bypass payload verified against filters.",
  "Syncing telemetry with command center.",
  "Executing blind SQLi on /api/graphql.",
  "Rate limit detected, throttling execution.",
  "Template injection payload successful.",
  "Exfiltrating data fragment...",
  "Session token identified in response."
];

export default function DashboardPage() {
  const [logs, setLogs] = useState<{id: number, text: string}[]>([]);
  const logsContainerRef = useRef<HTMLDivElement>(null);
  const logCounter = useRef(0);



  useEffect(() => {
    // Helper to generate a random log
    const createLog = (id: number) => {
      const nextLog = MOCK_LOGS[Math.floor(Math.random() * MOCK_LOGS.length)];
      
      const rand = Math.random();
      let level = '[INFO]';
      if (rand > 0.9) level = '[CRITICAL]';
      else if (rand > 0.75) level = '[HIGH]';
      else if (rand > 0.5) level = '[MEDIUM]';
      else if (rand > 0.3) level = '[LOW]';
      
      const time = new Date(Date.now() - (20 - id) * 1000).toLocaleTimeString('en-US', { hour12: false });
      return { id, text: `${time} ${level} ${nextLog}` };
    };

    // Pre-fill terminal so it doesn't look empty
    const initialLogs = Array.from({ length: 20 }).map((_, i) => {
      logCounter.current += 1;
      return createLog(logCounter.current);
    });
    setLogs(initialLogs);

    // Continuous fast stream
    const interval = setInterval(() => {
      logCounter.current += 1;
      const newLog = createLog(logCounter.current);
      newLog.text = newLog.text.replace(/:\d\d /, `:${new Date().getSeconds().toString().padStart(2, '0')} `); // Update to real current time
      
      setLogs(prev => {
        const newLogs = [...prev, newLog];
        return newLogs.slice(-25); // Keep last 25 logs for scrolling
      });
    }, 800);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (logsContainerRef.current) {
      logsContainerRef.current.scrollTop = logsContainerRef.current.scrollHeight;
    }
  }, [logs]);



  return (
    <div className="absolute inset-0 p-4 md:p-6 lg:p-8 flex flex-col font-sans text-text-primary overflow-hidden">
      <div className="w-full max-w-[1600px] mx-auto flex flex-col h-full">

      {/* Header */}
      <div className="flex items-center justify-between pb-4 shrink-0">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight flex items-center gap-2">
            <Radio className="w-5 h-5 text-brand-primary animate-pulse" />
            Threat Observatory
          </h1>
          <p className="text-[13px] text-text-secondary mt-0.5">
            Injection Lab assessment command center
          </p>
        </div>
        <Link href="/scanner" className="btn-cyber-primary px-5 py-2.5 text-sm flex items-center gap-2">
          <Target className="w-4 h-4" /> Deploy Assessment
        </Link>
      </div>

      {/* Main: Globe Left | Panels Right */}
      <div className="flex flex-1 gap-5 min-h-0 h-full">

        {/* ── Globe Column ── */}
        <div className="relative flex-1 shrink-0 rounded-2xl overflow-hidden border border-border-subtle/60 bg-[#060810]">
          {/* Status badge */}
          <div className="absolute top-4 left-4 z-10 flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-surface-hover/80 backdrop-blur border border-border-strong text-[10px] font-mono text-text-primary uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-brand-primary animate-pulse" />
              Live Telemetry
            </div>
            <div className="px-2 py-1 rounded bg-bg-base/70 backdrop-blur border border-border-subtle/40 text-[8.5px] font-semibold text-text-secondary uppercase tracking-widest">
              Simulated
            </div>
          </div>
          <GlobeVisualization />
        </div>

        {/* ── Right Panels Column ── */}
        <div className="flex-1 flex flex-col gap-4 overflow-y-auto h-full min-w-0 custom-scrollbar pr-1">

          {/* Active Payload Telemetry (Terminal) */}
          <div className="h-1/2 rounded-xl border border-border-subtle bg-[#0a0c10] p-4 flex flex-col relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-transparent to-[#0a0c10]/80 pointer-events-none z-10" />
            <div className="flex items-center justify-between mb-2 shrink-0 relative z-20">
              <h3 className="text-[10px] font-semibold text-brand-primary uppercase tracking-widest flex items-center gap-2">
                <Terminal className="w-3.5 h-3.5" /> Active Payload Telemetry
              </h3>
              <span className="w-2 h-2 rounded-full bg-brand-primary animate-pulse" />
            </div>
            <div ref={logsContainerRef} className="flex-1 overflow-y-auto [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none] font-mono text-[10px] sm:text-[11px] space-y-1.5 text-text-secondary relative z-0 pb-6 pr-2">
              {logs.map((log) => (
                <div 
                  key={log.id} 
                  style={{ 
                    animation: 'fadeInUp 0.3s ease forwards',
                    color: log.text.includes('[CRITICAL]') ? '#EF4444' :
                           log.text.includes('[HIGH]') ? '#F97316' :
                           log.text.includes('[MEDIUM]') ? '#EAB308' :
                           log.text.includes('[LOW]') ? '#10B981' :
                           log.text.includes('[INFO]') ? '#3B82F6' : 'inherit',
                    fontWeight: log.text.includes('[CRITICAL]') ? '700' :
                                log.text.includes('[HIGH]') ? '600' : 'normal'
                  }}
                >
                  {log.text}
                </div>
              ))}
            </div>
          </div>

        </div>
        </div>
      </div>
    </div>
  );
}
