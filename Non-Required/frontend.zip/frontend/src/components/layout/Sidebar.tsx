'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useStore } from '@/lib/store';
import { 
  LayoutDashboard, 
  ScanLine, 
  FileBarChart2, 
  User as UserIcon,
  History,
  Info,
  HelpCircle,
  LogOut,
  X,
} from 'lucide-react';
import { clsx } from 'clsx';


const menuItems = [
  { name: 'Workspace', href: '/dashboard', icon: LayoutDashboard },
  { name: 'Scanner', href: '/scanner', icon: ScanLine, badge: '55 Rules' },
  { name: 'Reports', href: '/reports', icon: FileBarChart2 },
  { name: 'History', href: '/history', icon: History },
  { name: 'Injection Details', href: '/injection-details', icon: Info },
  { name: 'Help', href: '/help', icon: HelpCircle },
  { name: 'Profile', href: '/profile', icon: UserIcon },
];

interface SidebarProps {
  isOpen?: boolean;
  onClose?: () => void;
}

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const pathname = usePathname();
  const { user, logout } = useStore();

  const handleLinkClick = () => {
    if (onClose) onClose();
  };

  return (
    <aside 
      className={clsx(
        "w-60 bg-bg-base border-r border-border-subtle flex flex-col h-screen fixed inset-y-0 left-0 lg:sticky lg:top-0 z-50 transition-transform duration-300 ease-in-out shadow-xl lg:shadow-none",
        isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}
    >
      {/* Brand Logo */}
      <div className="px-5 py-5 border-b border-border-subtle flex items-center justify-between gap-3 h-16">
        <Link href="/dashboard" className="flex items-center gap-3 group" onClick={handleLinkClick}>
          <div className="relative w-8 h-8 rounded-md border border-border-strong bg-surface-base flex items-center justify-center group-hover:border-brand-primary/40 transition-colors">
            {/* Mini parse-tree mark */}
            <svg viewBox="0 0 20 20" className="w-4 h-4" fill="none">
              <circle cx="10" cy="4" r="2" fill="var(--color-brand-primary)" />
              <circle cx="5" cy="12" r="1.5" fill="var(--color-text-secondary)" />
              <rect x="13.5" y="10.5" width="3" height="3" rx="0.5" fill="var(--color-brand-primary)" transform="rotate(45 15 12)" />
              <line x1="10" y1="6" x2="5" y2="10.5" stroke="var(--color-text-secondary)" strokeWidth="1" strokeOpacity="0.4" />
              <line x1="10" y1="6" x2="15" y2="10.5" stroke="var(--color-brand-primary)" strokeWidth="1" strokeOpacity="0.5" strokeDasharray="2 1.5" />
            </svg>
          </div>
          <div>
            <h1 className="font-semibold text-sm tracking-tight text-text-primary font-sans">
              Injection<span className="text-brand-primary">Lab</span>
            </h1>
            <p className="text-[10px] font-mono text-text-secondary mt-0.5">
              Security scanner
            </p>
          </div>
        </Link>
        
        {/* Close button for mobile */}
        <button 
          onClick={onClose}
          className="lg:hidden p-1.5 rounded-md text-text-secondary hover:text-text-primary hover:bg-surface-base transition-colors"
          aria-label="Close menu"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-5 space-y-0.5 overflow-y-auto">
        {menuItems.map((item) => {
          const isActive = pathname === item.href || (item.href !== '/dashboard' && pathname.startsWith(item.href));
          const Icon = item.icon;
          return (
            <Link
              key={item.name}
              href={item.href}
              onClick={handleLinkClick}
              className={clsx(
                "flex items-center justify-between px-3 py-2.5 rounded-md text-sm transition-all duration-150 group relative active:scale-[0.98]",
                isActive 
                  ? "text-text-primary font-medium bg-surface-hover shadow-sm border border-border-subtle" 
                  : "text-text-secondary font-medium hover:text-text-primary hover:bg-surface-hover border border-transparent"
              )}
            >

              <div className="flex items-center gap-3">
                <Icon className={clsx("w-4 h-4 transition-colors", isActive ? "text-brand-primary" : "text-text-secondary group-hover:text-text-primary")} />
                <span>{item.name}</span>
              </div>
              {item.badge && (
                <span className={clsx(
                  "text-[9px] font-mono px-2 py-0.5 rounded uppercase tracking-widest",
                  isActive ? "bg-brand-primary/10 text-brand-primary border border-brand-primary/20" : "bg-surface-hover border border-border-subtle text-text-secondary/70"
                )}>
                  {item.badge}
                </span>
              )}
            </Link>
          );
        })}
      </nav>

      {/* User Footer */}
      <div className="p-4 space-y-2">
        <button
          onClick={logout}
          className="w-full flex items-center justify-start gap-2 px-3 py-2.5 rounded-md text-xs font-medium text-text-secondary hover:bg-surface-base hover:text-text-primary border border-transparent hover:border-border-subtle transition-all active:scale-[0.98]"
        >
          <LogOut className="w-3.5 h-3.5" />
          Sign out
        </button>
      </div>
    </aside>
  );
}
