import { create } from 'zustand';
import { api } from '@/lib/api';

export interface Finding {
  type: string;
  injectionFamily: string;
  location: string;
  parameter?: string;
  paramValue?: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low' | 'Info';
  confidence: 'Confirmed' | 'Likely' | 'Possible' | 'Low';
  cvss: number;
  cwe: string;
  owasp: string;
  description: string;
  evidence: string;
  pocPayload: string;
  recommendation: string;
}

export interface ScanResult {
  targetUrl: string;
  scanTimestamp: string;
  parameters: string[];
  paramValues: Record<string, string>;
  pathSegments: string[];
  domain: string;
  techStackClues: string[];
  potentialInjectionPoints: {
    type: string;
    location: string;
    risk: string;
    reason: string;
  }[];
  findings: Finding[];
  summary: {
    totalPages: number;
    injectionPoints: number;
    parameters: number;
    riskScore: number;
    highestSeverity: string;
    owaspCoverage: string[];
    familiesTested: string[];
    injectionFamilyCounts: Record<string, number>;
  };
}

interface ScannerState {
  url: string;
  setUrl: (url: string) => void;
  authorized: boolean;
  setAuthorized: (authorized: boolean) => void;
  loading: boolean;
  result: ScanResult | null;
  error: string;
  setError: (error: string) => void;
  setResult: (result: ScanResult | null) => void;
  startScan: () => Promise<void>;
  reset: () => void;
}

export const useScannerStore = create<ScannerState>((set, get) => ({
  url: '',
  setUrl: (url: string) => set({ url }),
  authorized: false,
  setAuthorized: (authorized: boolean) => set({ authorized }),
  loading: false,
  result: null,
  error: '',
  setError: (error: string) => set({ error }),
  setResult: (result: ScanResult | null) => set({ result }),
  startScan: async () => {
    const { url, authorized } = get();
    if (!authorized) {
      set({ error: 'You must confirm authorization before scanning.' });
      return;
    }

    set({ loading: true, error: '', result: null });
    try {
      const res = await api.post('/scanner/analyze', { url, authorized });
      set({ result: res.data, loading: false });
    } catch (err: any) {
      set({ 
        error: err.response?.data?.error || err.message || 'An unexpected error occurred during the scan.', 
        loading: false 
      });
    }
  },
  reset: () => set({ url: '', authorized: false, loading: false, result: null, error: '' })
}));
